from flask import Flask
from app.view import view_bp
from app.create import create_bp

def create_app():
    app = Flask(__name__)
    app.register_blueprint(view_bp, url_prefix='/view')
    app.register_blueprint(create_bp, url_prefix='/create')
    return app