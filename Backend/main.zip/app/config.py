import os

os.environ['PATH'] = 'C:\\Users\\greeshma\\Downloads\\instantclient-basic-windows.x64-21.9.0.0.0dbru\\instantclient_21_9;' + os.environ['PATH']

# Set the connection parameters
oracle_config = { 'hostname': 'az6F72ldbp1.az.uta.edu',
'port': '1523',
'service_name': 'pcse1p.data.uta.edu',
'username': 'gxj4507',
'password': 'sqlplusG4507' } 